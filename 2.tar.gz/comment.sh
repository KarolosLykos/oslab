# Erwtima 1

# Otan vriskoume to pattern "/*", auto mporei na akolou8eitai
# eite apo keno eite apo xaraktira allagis grammis (\n)
# 8eloume otan vriskoume "/*" na to antikatatastoume me "/**"
# xwris omws na epireazontai ta hdh uparxonta patterns "/**"
# Ara to ulopoioume en merei me to sed 's,/\* ,/\*\*\n,g' cin.c
# diladi otan vriskei "/* " na to antika8ista me to "/**\n".
# Antistoixa otan vriskei to "/*\n" 8a to antika8ista pali me to "/**\n"
# kai auto ulopoieitai me tin sed 's,/\*\n,/\*\*\n,g' cin.c
# Epeita otan vriskei to "/**" apla 8a koitaksei an uparxei meta apo auto
# xaraktiras allagis grammis opote to ulopoioume me tin sed 's,/\*\* ,/\*\*\n,g' cin.c
# h opoia mas leei oti an vrei to "/** " na to antikatastisei me to "/**\n"
# Twra exoume etoima ta "/**" kai stis dikes tous grammes
# 8eloume na dior8wsoume kai to telos tou ka8e comment
# opou diladi vriskoume " */" apla na tou allazoume grammi ("\n*/")
# me tin sed 's, \*/,\n\*/,g' cin.c
# Telos, autes tis 4 entoles tis syndiazoume se 1 kai apo8ikeuoume
# to kainourio arxeio doxygen se ena arxeio cout.c
# opote i oloklirwmeni entoli exei tin eksis morfi:

sed 's,/\* ,/\*\*\n,g;  s,/\*\n,/\*\*\n,g;  s,/\*\* ,/\*\*\n,g;  s, \*/,\n\*/,g'  cin.c > cout.c



# Erwtima 2

# 8eloume ta kena diastimata akolou8oumena apo telos grammis
# Meta apo auta ta diastimata 8a PROSTE8EI (gia auto yparxei to &)
# to keimeno "//-->Trailing spaces", opote i entoli 8a exei tin morfi:

sed 's,[ *]$,&//-->Trailing spaces,g' cout.c > cout_spaces.c
