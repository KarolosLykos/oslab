# SIMEIOSI --> Kai sta 2 erwtimata xrisimopoieitai san eisodos ena arxeio me onoma apokleistika input.txt
#              Alla onomata den ginontai dekta, ektos ki an allaksei o parakatw kwdikas

# Erwtima 1 (LDAP)

# Xrisimopoioume ton sed gia antikatastisoume ta : me kena
# Etsi to awk 8a ksexwrizei tis stiles (dimiourgoume etsi 4 stiles)
# kai apo8ikeuoume se ena kainourio arxeio, to input_columns.txt

sed 's,:, ,g' input.txt > input_columns.txt

# Epeita xrisimopoioume to neo arxeio san eisodo sto awk
# Den xreizomaste ta BEGIN 'h END, opote proxwrame kanonika
# kai ektypwnoume ta LDAP records se ena neo arxeio, to LDAP_Records.txt
# Me to $1 anaferomaste stin prwti stili (username) kai etsi to ektypwnoume
# meta to "uid=" kai paromoia prattoume gia tis ypoloipes 3 stiles,
# enw exoume frontisei kai gia ta kena anamesa stis eggrafes...

awk '{print "dn: uid=", $1, ", dc=upatras, dc=gr"} {print "cn:",$2,$3} {print "sn:",$3} {print "telephoneNumber:",$4,"\n"}' input_columns.txt > LDAP_Records.txt




# Erwtima 2 (XHTML)

# Xrisimopoioume kai pali ton sed edw gia ton idio logo

sed 's,:, ,g' input.txt > input_columns.txt

# Xrisimopoioume san orisma pali to input_columns.txt gia na ftiaksoume ton XHTML pinaka
# Opws kai sto proigoumeno erwtima, ektypwnoume ton XHTML kwdika mazi me tis stiles ($1,$2,$3,$4)
# kai to apo8ikeuoume se ena arxeio XHTML.html
# Auto to arxeio mporoume na to anoiksoume pia me ton browser mas
# gia na doume tis eggrafes se morfi pinaka...
# Edw xrisimopoioume tin BEGIN gia ektypwsoume to header tou pinaka (kai na arxisoume ton kwdika)
# Meta xrisimopoioume toses print oses kai oi eggrafes gia na tis typwsoume se grammes (me ton katallilo kwdika)
# Telos xrisimopoioume kai tin END gia na teleiwsoume to swma tou kwdika mas

awk 'BEGIN {print "<html><body><table class=\"reference\" cellspacing=\"0\" cellpadding=\"0\" border=\"1\" width=\"100%\"><tr><th valign=\"top\" align=\"left\" width=\"25%\">Username</th><th valign=\"top\" align=\"left\" width=\"25%\">First Name</th><th valign=\"top\" align=\"left\" width=\"25%\">Last Name</th><th valign=\"top\" align=\"left\" width=\"25%\">Telephone number</th></tr>"} {print "<tr><td valign=\"top\">",$1,"</td><td valign=\"top\">",$2,"</td><td valign=\"top\">",$3,"</td><td valign=\"top\">",$4,"</td></tr>"} END {print "</table></body></html>"}' input_columns.txt > XHTML.html
