#include"../system.h"
#include <stdio.h>
#include <minix/config.h>

#if USE_MYVER

/* the handler of SYS_MYVER call only 
 * copies the num from kernel space
 * to user space */

PUBLIC int do_myver(m_ptr)
message *m_ptr;
{
	char *num = m_ptr->m7_p1; /* takes message */
	/* char *r = OS_VERSION */	
	return OS_VERSION;
}

#endif /* USE_MYVER */
