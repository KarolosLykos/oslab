#include"../system.h"

#if USE_MYMUX

/* the handler of SYS_MYMUX call only 
 * copies the num from kernel space
 * to user space */

PUBLIC int do_mymux(m_ptr)
message *m_ptr;
{
	int num = m_ptr->m1_i1; /* takes message */
	return 4260 * num;  /* returns mux */
}

#endif /* USE_MYMUX */
