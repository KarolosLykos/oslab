#include <stdio.h>
#include <stdlib.h>
#include <minix/config.h>

void main(int argc, char *argv[])
{
	 
	char *res = myver(argv[1]); /*calls myver()*/
	printf("KERNEL VERSION IS:%s", res); /* prints version */
	
	return; /* terminates */
}
