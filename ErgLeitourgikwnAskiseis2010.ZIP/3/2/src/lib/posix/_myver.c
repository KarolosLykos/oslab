#include <lib.h>
#include <unistd.h>
#include <string.h>

PUBLIC int myver(num)
const char *num;
{
	message m; /* declaration of message */

	m.m3_ca1 = num; /* take message */

	return (_syscall(MM, MYVER, &m)); /* invokes system call MYVER */
}
