#include <lib.h>
#include <unistd.h>
#include <string.h>

PUBLIC int mymux(int num)
{
	message m; /* declaration of message */

	m.m1_i1 = num; /* take message */

	return (_syscall(MM, MYMUX, &m)); /* invokes system call MYMUX */
}
