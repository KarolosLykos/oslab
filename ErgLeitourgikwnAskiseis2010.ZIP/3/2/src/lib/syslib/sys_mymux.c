#include "syslib.h"
/* this function takes num as input from user space
 * and puts it in a message which it sends to 
 * system task, which afterwards calls SYS_MYMUX */

PUBLIC int sys_mymux(int num)
{
	message m; /* declarations */
	int result;

	m.m1_i1=num; /* put in message */

	result = _taskcall(SYSTASK, SYS_MYMUX, &m); /* call SYS_MYMUX */
	return(result);
}
