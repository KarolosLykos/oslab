#include "syslib.h"
/* this function takes num as input from user space
 * and puts it in a message which it sends to 
 * system task, which afterwards calls SYS_MYVER */

PUBLIC int sys_myver(num)
void *num;
{
	message m; /* declarations */
	int result;

	m.m7_p1=num; /* put in message */

	result = _taskcall(SYSTASK, SYS_MYVER, &m); /* call SYS_MYVER */
	return(result);
}
