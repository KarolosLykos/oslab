#include <stdio.h>
#include <stdlib.h>

void main(int argc, char *argv[])
{
	int num = atoi(argv[1]); /*converts second argument passed into its
				 *integer represantation */
	int res = mymux(num); /*calls mymux() with the given number as input*/
	printf("Result = %d\n", res); /* prints the 
				    * mux of the given number x 4260 */
	
	return 0; /* terminates */
}
