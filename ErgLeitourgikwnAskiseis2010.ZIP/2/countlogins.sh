#!/bin/bash

#print a start message
echo "The script starts now."

#say hi to user getting the correct username from $USER
echo "Hi, $USER!"

#print a message explaining the array below
echo "Count of logins for each user:"

#first take list of recently logged on users from last
#-we only want to print users that have at least logged in once,
#so last will do just fine
#then, using the little programming language awk on this list,
#we have a counter that adds up for each user and a for loop
#which counts the total logins for the user in question -j shows the user-
# Finally, the array we have created is sorted numerically 
#(according to the logins' totals) via sort -n and then reversed 
#via -r so that we have it in descending order
#more is also used so as to have the onscreen printing
#of our rather large array, under control.
last | awk '{count[$1]++}END{for(j in count) print count[j] " logins" , j}' | sort -n -r | more

#script by student Georgia Spyraki, AM 4260
