#!/bin/bash

#print a starting message
echo "The script starts now."

#say hi to user getting the correct username from $USER
echo "Hi, $USER!"

#print the url parameter the user has typed when 
#he/she run the script
echo $1

#get the contents of this url via wget and
#store them in a temporary file called test.txt
wget $1 -O test.txt

#using the little programming language AWK
#a for loop checks the entire test.txt file
#for emails, with an if-check
awk '
{
  for (i=1;i<=NF;i++) {
#if there are matches to the description, which is
#~ (which means 'like') alpharethmetic@alpharethmetic.more
#(in code [-A-z0-9.]+@[-A-z0-9.]+)
       if ( $i ~ /[-A-z0-9.]+@[-A-z0-9.]+/)
{
#they are printed:   
      print $i      
       }
  }
}' test.txt

#Finally, since the use of the test.txt is only temporar
#we do not forget to delete via rm (=remove) command.
rm test.txt

#script by student Georgia Spyraki, AM 4260
