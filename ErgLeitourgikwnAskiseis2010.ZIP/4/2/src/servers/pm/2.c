#include <stdio.h>
#include <stdlib.h>
#include <lib.h>
#include <unistd.h>
#include <string.h>
#include <minix/type.h>

int main(int argc, char *argv[])
{
	int pid = atoi(argv[1]); /* converts 2nd arg into integer */

	message m; /* declaration of message */

	int r=1;

	m.m1_i1 = pid; /* sends message */

	r = _syscall(MM, 57, &m); /* invokes system call do_pidinfo */

	if (r!=0)
	{
		printf("\nSystem call terminated. Exit status: %d", r);
		return r;
	}

	printf("Data for process ID=%d: %d", pid,r);

	return 0;
}
