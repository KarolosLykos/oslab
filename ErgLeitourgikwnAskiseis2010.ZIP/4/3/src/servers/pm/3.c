/* This file uses the system call do_processes */
#include <lib.h> /* for system calls */
#include <stdio.h> /* for basic io */
#include <stdlib.h> /* for system() function */
#include <unistd.h> /* for sleep() function */
#include <minix/type.h> /* for clock_t and pid_t definitions */

/* creates system call do_processes */
int main(void)
{
	/* this struct will hold the values our system call computes */
	struct statistics{
		int nprocesses, npause, nwait;
		pid_t maxstime;
		clock_t totalutime;
	};
	struct statistics stats;
	
	int r; /* used to determine the exit status of the system call */
	
	message m;
		
	m.m1_p1 = (char*) &stats; /* send message */ 
                
	/* invokes do_processes system call */
	r = _syscall(MM, 50, &m); 

	/* system call didn't make it */	
	if (r != 0)
	{
		printf("\nSystem call terminated with exit status:%d", r);
		return r;
	}
	
	/* from here down print the info we want */
	printf("\nProcesses' statistics");
	printf("\n*****************************************");
	printf("\nTotal of processes: %d", stats.nprocesses);
	printf("\nTotal of WAITING processes: %d", stats.nwait);
	printf("\nTotal of PAUSED processes: %d", stats.npause);
	printf("\nPid of process with max stime: %d", stats.maxstime); 
	printf("\nTotal utime: %2f", (double)(stats.totalutime + 0.0)); 

	
	return 0;
}
