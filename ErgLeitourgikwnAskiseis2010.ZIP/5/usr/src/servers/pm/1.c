/* This file uses the system call do_memholes */

#include <lib.h> /* for system calls */
#include <minix/type.h> /* for phys_clicks definition */
#include <stdio.h> /* for basic io */
#include <stdlib.h> /* for system() function */
#include <unistd.h> /* for sleep() function */
#include <math.h> /* for pow() function */

#define MB pow(2, 20) /* number of bytes in a MegaByte */
#define pcs sizeof(phys_clicks) /* number of bytes in a phys_click */

/* makes the system call do_memholes */
int main(void)
{
	/* this struct will hold the values the system call computes */
	struct statistics {
		phys_clicks min, max, nholes;
		float avg_size, std_dev_size;
	};
	
	struct statistics stats;
	
	/* these variables will hold the converted results in MegaBytes */
	phys_clicks nholes;
	float max_size_in_mb, min_size_in_mb, avg_size_in_mb, std_dev_size_in_mb;
	
	int r; /* this will be used to determine the exit status of the system call */
	
	/* counter for displaying the number of iterations the loop executes */
	unsigned int ctr; 
	
	ctr = 0; 
	
	while (TRUE) /* run forever */
	{
		message m; /* message structure which will pass to the system call */
		m.m1_p1 = (char*) &stats; /* passes the adress of the structure instance */
								  /* in a char pointer member of message structure */
		
		r = _syscall(MM, 69, &m); /* invokes do_memholes system call */
		
		/* system call didn't make it */
		if (r != 0)
		{
			printf("\nSystem call do_memholes terminated with exit status: %d", r);
			return r;
		}
		
		/* Because in system call computed the stats in phys_clicks and not in MegaBytes */
		/* here we do the convertion */
		nholes = stats.nholes;
		max_size_in_mb = (stats.max * pcs) / MB;
		min_size_in_mb = (stats.min * pcs) / MB;
		avg_size_in_mb = (stats.avg_size * pcs) / MB;
		std_dev_size_in_mb = (stats.std_dev_size * pcs) / MB;
		
		system("clear"); /* clear the screen */
		
		printf("\nPress CTRL + C to exit!");
		printf("\nMemory holes statistics after %d iterations", ctr);
		printf("\n----------------------------------------------");
		printf("\nin phys_clicks");
		printf("\n----------------------------------------------");
		printf("\n%d\t%d\t%d\t%.2f\t%.2f", 
		stats.nholes, stats.max, stats.min, 
		stats.avg_size, stats.std_dev_size);
		
		/* because the allocated memory in VMWare for my Minix3 was 256MBytes */
		/* the values converted in MegaBytes were bellow an integer value */
		/* i used a second table for them using floats only */
		/* hope this is not a problem */
		printf("\n----------------------------------------------");
		printf("\nin MegaBytes");
		printf("\n----------------------------------------------");
		printf("\n%d\t%.2f\t%.2f\t%.2f\t%.2f\n",
		nholes, max_size_in_mb, min_size_in_mb, 
		avg_size_in_mb, std_dev_size_in_mb);
		
		ctr++; /* increase the iteration counter by one */
		
		sleep(1); /* do nothing for one second */
	}
	
	return 0;
}
