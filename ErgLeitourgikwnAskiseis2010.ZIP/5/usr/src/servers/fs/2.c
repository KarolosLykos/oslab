/* This file uses the system call do_fragrate */

#include <lib.h> /* for system calls */
#include <stdio.h> /* for basic io */
#include <stdlib.h> /* for malloc() */
#include <string.h> /* for string manipulation */

/* makes the system call do_fragrate */
int main(int argc, char *argv[])
{
	char *path; /* here it will be stored the path entered by argument */
	int r; /* this will be used to determine the exit status of the system call */
	/* this structure will hold the values the system call computes  */
	struct fragmentation {
		int total_ctr, frag_ctr;
		float frag_rate;
	};
	
	struct fragmentation frag;
	
	message m; /* message structure which will pass to the system call */
	
	path = NULL; /* needed pointer intialization */
	
	/* usage check, only one argument is valid */
	if (argc != 2)
	{
		printf("\nUsage: ./2 /path/to/file\n");
		return 1;
	}
	
	/* make enough space for argument to fit */
	path = (char*) malloc(sizeof(argv[1]));
	
	/* malloc() didn't make it, exit with pride */
	if (path == NULL)
	{
		printf("\nCouldn't allocate memory for path entered! Exiting...");
		return 1;
	}
	
	strcpy(path, argv[1]); /* copy argument to allocated space */
	
	/* fill the message strucure with the needed values system call needs */
	m.m1_i1 = strlen(path) + 1; /* length of the path + the terminating character \0 */
	m.m1_p1 = (char*) path; /* adress of the first byte of path entered */
	m.m1_p2 = (char*) &frag; /* adress of variable which will hold the result */
	
	r = _syscall(FS, 69, &m); /* invokes do_fragrate system call */
	
	if (r != 0) /* system call didn't make it */
	{
		printf("\nSystem call frag_rate terminated with exit status: %d\n", r);
		free(path); /* free previously allocated space */
		return r;
	}
	
	printf("\nThe file you have entered: %s", argv[1]);
	printf("\nTotal blocks: %d \nFragmented blocks: %d", frag.total_ctr, frag.frag_ctr);
	printf("\nFragmentation rate: %.1f%%\n", frag.frag_rate);
	
	free(path); /* free previously allocated space */
	
	return 0;
}
