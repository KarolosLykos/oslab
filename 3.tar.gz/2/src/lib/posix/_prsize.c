/* All same as _acprocs.c */

#include <lib.h>
#include <unistd.h>

PUBLIC int prsize(int pid)
{
	message m;
	
	/* This one takes an integer parameter */
	m.m1_i1=pid;
	
	/* and passes it while calling function with
	call number equal to PRSZ (=66) */
	return(_syscall(MM,PRSZ,&m));
}
