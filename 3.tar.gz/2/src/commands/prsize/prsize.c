#include <stdio.h>

int main(int argc, char *argv[])
{
	if (argc<2){
		printf("\nPlease give process id as well.\n\n");
	}
	else if (argc>2){
		printf("\nPlease give only one parameter, the process id.\n\n");
	}
	else{
		/* This is where the function is called and the argument is sent */
		/* It's the *argv[1] because *argv[0] is the name of the command */
		prsize(*argv[1]);
	}
}
