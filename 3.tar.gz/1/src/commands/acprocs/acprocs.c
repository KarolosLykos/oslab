#include <stdio.h>

int main(int argc, char *argv[])
{	
	/* This is where the function is called */
	return(acprocs());
}
