/*
Perform system call with given
parameters (in this case none)
*/

#include <lib.h>
#include <unistd.h>

PUBLIC int acprocs(void)
{
	/* Message which will contain the parameters passed */
	message m;
	
	/* Call function with call number equal to ACPR (=64)
	while passing the arguments */
	return(_syscall(MM,ACPR,&m));
}
