/* In here we retrieve the parameters (in this case none) */

#include <lib.h>
#include <unistd.h>

PUBLIC int hinfo(void)
{
	/* message to pass the parameters to system call's function */
	message m;
	
	/* No parameters passed */
	
	/* Here we call the function which has call number equal to HINFO (=64) */
	return(_syscall(MM,HINFO,&m));
}
