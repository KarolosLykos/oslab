#include <stdio.h>

int main(int argc, char *argv[])
{	
	printf("Values in KB:");
	for (;;)
	{
		/* This is were the function is called */
		hinfo();
		sleep(1);
	}
}
